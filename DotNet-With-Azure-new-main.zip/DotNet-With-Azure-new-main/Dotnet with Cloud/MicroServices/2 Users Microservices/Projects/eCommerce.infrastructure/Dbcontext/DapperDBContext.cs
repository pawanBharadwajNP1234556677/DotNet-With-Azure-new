﻿
using Microsoft.Extensions.Configuration;
using Npgsql;
using System.Data;


namespace eCommerce.infrastructure.Dbcontext;

public class DapperDBContext
{
    private readonly IConfiguration _configuration;
    private readonly IDbConnection conn;
    public DapperDBContext(IConfiguration configuration)
    {
        this._configuration = configuration;
        string ConString = _configuration.GetConnectionString("PostgresConnection");

        // create new connection
        conn = new NpgsqlConnection(ConString);
    }


    public IDbConnection GetDbConnection => conn;
}

