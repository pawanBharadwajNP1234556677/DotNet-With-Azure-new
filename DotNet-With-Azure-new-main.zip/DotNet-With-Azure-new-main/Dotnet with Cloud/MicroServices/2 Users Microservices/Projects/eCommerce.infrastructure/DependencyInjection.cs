﻿using eCommerce.Core.DIContracts.Interfaces;
using eCommerce.Core.ServiceContracts.Interfaces;
using eCommerce.infrastructure.Dbcontext;
using eCommerce.infrastructure.DIContracts.Repositories;
using Microsoft.Extensions.DependencyInjection;


namespace eCommerce.infrastructure
{
    public static class DependencyInjection
    {

        // extension method to add infructure services too dependency injection container

        public static IServiceCollection AddInfrastructure(this IServiceCollection service)
        {
            // TODO : Add ervices to IOC Conainer 
            // Infrastruture services often include data access, caching and other low-lev components

            service.AddTransient<IUserRepository, UserRepository>();
            service.AddTransient<DapperDBContext>();

            return service;

        }
    }
}
