﻿using Dapper; // required to use ExecuteAsync
using eCommerce.Core.Common.Enums;
using eCommerce.Core.DIContracts.Interfaces;
using eCommerce.Core.Entties;
using eCommerce.infrastructure.Dbcontext;


namespace eCommerce.infrastructure.DIContracts.Repositories;

public class UserRepository : IUserRepository
{
    private readonly DapperDBContext _dapperDBContext;

    public UserRepository(DapperDBContext dbContext)
    {
        this._dapperDBContext = dbContext;
    }

    public async Task<ApplicaionUser?> AddUser(ApplicaionUser user)
    {
        user.UserID = Guid.NewGuid();

        string query = " INSERT INTO c  (\"UserID\" , \"Email\" , \"PersonName\" , \"Gender\" , \"Password\" )   " +
                       " VALUES (@UserID , @Email, @PersonName, @Gender, @Password  )  ";

        int rowsAffected = await _dapperDBContext.GetDbConnection.ExecuteAsync(query, user);

        if (rowsAffected > 0)
        {
            return user;
        }
        else
        {
            return null;
        }

    }



    public async Task<ApplicaionUser?> GetUserByEmailAndPassword(string? Email, string? Password)
    {

        string query = "SELECT * FROM public.\"Users\" WHERE \"Email\" = @EMAIL AND  \"Password\" = @PASSWORD";

        var parameters = new { EMAIL = Email, PASSWORD = Password };

        return await _dapperDBContext.GetDbConnection.QueryFirstOrDefaultAsync<ApplicaionUser>(query, parameters);
    }
}

