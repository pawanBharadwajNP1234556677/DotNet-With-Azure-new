﻿using eCommerce.Core.ServiceContracts.Interfaces;
using eCommerce.Core.ServiceContracts.Services;
using eCommerce.Core.Validators;
using FluentValidation;
using Microsoft.Extensions.DependencyInjection;


namespace eCommerce.Core
{
    public static class DependencyInjection
    { 
        // extension method to add Core services too dependency injection container

        public static IServiceCollection AddCore(this IServiceCollection service)
        {
            // TODO : Add ervices to IOC Conainer 
            service.AddTransient<IUserService, UserService>();

            service.AddValidatorsFromAssemblyContaining<LoginRequestDTOValidator>();   

            return service;

        }
    }
}
