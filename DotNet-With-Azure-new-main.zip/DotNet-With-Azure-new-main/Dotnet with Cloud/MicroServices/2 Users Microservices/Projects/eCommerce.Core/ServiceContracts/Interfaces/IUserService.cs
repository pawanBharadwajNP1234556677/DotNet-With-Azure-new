﻿using eCommerce.Core.DTO.Request;
using eCommerce.Core.DTO.Response;

namespace eCommerce.Core.ServiceContracts.Interfaces;

public interface IUserService
{
    Task<AuthenticationResponseDTO?> Login(LoginRequestDTO loginRequestDTO);


    Task<AuthenticationResponseDTO?> Register(RegisterRequestDTO registerRequestDTO);




}

