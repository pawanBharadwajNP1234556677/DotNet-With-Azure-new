﻿using AutoMapper;
using eCommerce.Core.DIContracts.Interfaces;
using eCommerce.Core.DTO.Request;
using eCommerce.Core.DTO.Response;
using eCommerce.Core.Entties;
using eCommerce.Core.ServiceContracts.Interfaces;


namespace eCommerce.Core.ServiceContracts.Services;


public class UserService : IUserService
{

    private readonly IUserRepository _IUserRepository;
    private readonly IMapper _mapper;

    public UserService(IUserRepository IUserRepository, IMapper mapper)
    {
        this._IUserRepository = IUserRepository;
        this._mapper = mapper;

        _mapper.ConfigurationProvider.AssertConfigurationIsValid();

    }

    public async Task<AuthenticationResponseDTO?> Login(LoginRequestDTO loginRequestDTO)
    {
        ApplicaionUser? user = await _IUserRepository.GetUserByEmailAndPassword(loginRequestDTO.Email, loginRequestDTO.Password);

        if (user == null)
        {
            return null;
        }

        /*   return new AuthenticationResponseDTO(
                user.UserID,
                user.Email,
                user.PersonName,
                user.Gender,
                "token",
                true
           );*/

        return _mapper.Map<AuthenticationResponseDTO>(user)
            with { success=true, Token="Success" };

    }

    public async Task<AuthenticationResponseDTO?> Register(RegisterRequestDTO registerRequestDTO)
    {
        ApplicaionUser user = new ApplicaionUser()
        {
            PersonName = registerRequestDTO.PersonName,
            Email = registerRequestDTO.Email ,
            Password = registerRequestDTO.Password,
            Gender = registerRequestDTO.Gender
        };
        ApplicaionUser? RegisteredUser = await _IUserRepository.AddUser(user);

        if (RegisteredUser == null)
        {
            return null;
        }
       /* return new AuthenticationResponseDTO(
            RegisteredUser.UserID,
            RegisteredUser.Email,
            RegisteredUser.PersonName,
            RegisteredUser.Gender,
            "token",
             true
            );*/


        return _mapper.Map<AuthenticationResponseDTO>(RegisteredUser)
            with  { success = true, Token = "Success" };


    }
}

