﻿
namespace eCommerce.Core.Common.Enums;

public enum Genderoptons
{
    Male, Female, Others
}

