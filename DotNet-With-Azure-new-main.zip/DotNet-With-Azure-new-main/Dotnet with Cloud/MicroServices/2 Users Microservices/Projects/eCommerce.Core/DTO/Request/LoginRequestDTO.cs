﻿namespace eCommerce.Core.DTO.Request;

public record LoginRequestDTO (
    string? Email,
    string? Password
    );



