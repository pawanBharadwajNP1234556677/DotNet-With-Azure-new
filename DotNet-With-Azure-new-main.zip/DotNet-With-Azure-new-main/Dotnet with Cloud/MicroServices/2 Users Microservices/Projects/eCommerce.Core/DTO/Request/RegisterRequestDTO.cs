﻿using eCommerce.Core.Common.Enums;

namespace eCommerce.Core.DTO.Request;

public record RegisterRequestDTO(
   string? Email, 
   string? Password, 
   string? PersonName,
   string? Gender
    
    );



