﻿namespace eCommerce.Core.DTO.Response;

public record AuthenticationResponseDTO(
    Guid UserId,
    string? Email,
    string? PersonName,
    string? Gender,
    string? Token,
    bool success

    )
{
    // default constructor
    public AuthenticationResponseDTO(): this(default, default, default, default, default, default)
    {
    }


}

