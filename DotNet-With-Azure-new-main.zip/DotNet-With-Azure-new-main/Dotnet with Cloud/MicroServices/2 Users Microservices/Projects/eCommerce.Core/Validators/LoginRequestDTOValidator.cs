﻿using eCommerce.Core.DTO.Request;
using FluentValidation;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace eCommerce.Core.Validators
{
    public class LoginRequestDTOValidator : AbstractValidator<LoginRequestDTO>
    {
        public LoginRequestDTOValidator()
        {
            // add email address vaidation
            RuleFor(t => t.Email)
                .NotEmpty().WithMessage("Email should not be empty!")
                .EmailAddress().WithMessage("Enter proper Email Address");

            // add password vaidation
            RuleFor(t => t.Password)
                .NotEmpty().WithMessage("Password should not be empty!");
        }
    }
}
