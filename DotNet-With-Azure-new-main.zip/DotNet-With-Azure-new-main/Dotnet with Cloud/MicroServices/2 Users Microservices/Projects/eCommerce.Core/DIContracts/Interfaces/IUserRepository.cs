﻿

using eCommerce.Core.Entties;

namespace eCommerce.Core.DIContracts.Interfaces;

public interface IUserRepository
{
    Task<ApplicaionUser?> AddUser(ApplicaionUser user);

    Task<ApplicaionUser?> GetUserByEmailAndPassword(string? Email, string? Password);





}

