using AutoMapper;
using eCommerce.Core;
using eCommerce.Core.Mappers;
using eCommerce.infrastructure;
using FluentValidation.AspNetCore;
using Microsoft.Extensions.DependencyInjection;
using System.Text.Json.Serialization;
using UserManagement.Middleware;

var builder = WebApplication.CreateBuilder(args);


// add infrasructure services
builder.Services.AddInfrastructure();
builder.Services.AddCore();


// Register services to the container.
builder.Services.AddControllers().AddJsonOptions(
    options =>
    {
        options.JsonSerializerOptions.Converters.Add(new JsonStringEnumConverter());
    }
    );            
builder.Services.AddEndpointsApiExplorer();   // Enables minimal APIs and is required for Swagger
builder.Services.AddSwaggerGen();             // Registers Swagger generator

// add automapper
//builder.Services.AddAutoMapper(typeof(ApplicationUserMappingProfile).Assembly);
// run this then this wont throw error dotnet add package AutoMapper.Extensions.Microsoft.DependencyInjection
var mapperConfig = new MapperConfiguration(cfg =>
{
    cfg.AddMaps(typeof(ApplicationUserMappingProfile).Assembly);
});
IMapper mapper = mapperConfig.CreateMapper();
builder.Services.AddSingleton(mapper);


// fluent validations
builder.Services.AddFluentValidationAutoValidation();

var app = builder.Build();

// Middleware pipeline configuration
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();       // Enables middleware to serve Swagger JSON
    app.UseSwaggerUI();     // Enables Swagger UI for visual documentation
}





app.UseExceptionHandlingMiddleware();
app.UseAuthentication();
app.UseAuthorization();     // Adds authorization middleware
app.UseRouting();

app.MapControllers();       // Maps controller endpoints to the pipeline



app.Run();                  // Runs the application
