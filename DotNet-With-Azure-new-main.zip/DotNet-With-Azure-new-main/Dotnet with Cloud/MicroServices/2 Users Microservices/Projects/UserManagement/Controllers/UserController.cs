﻿using eCommerce.Core.DTO.Request;
using eCommerce.Core.DTO.Response;
using eCommerce.Core.ServiceContracts.Interfaces;
using Microsoft.AspNetCore.Mvc;

namespace UserManagement.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class UserController : ControllerBase
    {
        private readonly IUserService _userService;
        public UserController(IUserService userService)
        {
            this._userService = userService;
        }

        [HttpGet("Index")]
        public async Task<IActionResult> Index()
        {
            return Ok("Hello from Index!");
        }

        [HttpPost("Register")]
        public async Task<IActionResult> Register(RegisterRequestDTO registerRequestDTO)
        {
            if (registerRequestDTO == null)
            {
                return BadRequest("Request body invalid!!");
            }

            AuthenticationResponseDTO? response = await _userService.Register(registerRequestDTO);

            if (response == null || !response.success)
            {
                return BadRequest(response);
            }

            return Ok(response);
        }



        [HttpPost("Login")]
        public async Task<IActionResult> Login(LoginRequestDTO loginRequestDTO)
        {
            if (loginRequestDTO == null)
            {
                return BadRequest("Invalid login data!!");
            }

            AuthenticationResponseDTO? response = await _userService.Login(loginRequestDTO);

            if (response == null || !response.success)
            {
                return Unauthorized(response);
            }

            return Ok(response);
        }







    }
}
