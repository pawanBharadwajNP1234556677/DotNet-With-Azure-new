﻿using eCommerce.BusinessLogicLayer.Mappers;
using eCommerce.BusinessLogicLayer.ServiceContracts;
using Microsoft.Extensions.DependencyInjection;
using eCommerce.BusinessLogicLayer.Validators;
using FluentValidation;
using AutoMapper;

namespace eCommerce.ProductsService.BusinessLogicLayer;

public static class DependencyInjection
{
  public static IServiceCollection AddBusinessLogicLayer(this IServiceCollection services)
  {
        //TO DO: Add Business Logic Layer services into the IoC container
        // Replace this line:
        // services.AddAutoMapper(typeof(ProductAddRequestToProductMappingProfile));

        // With this line:
        services.AddAutoMapper(cfg => { cfg.AddProfile<ProductAddRequestToProductMappingProfile>(); });
         



        services.AddValidatorsFromAssemblyContaining<ProductAddRequestValidator>();

    services.AddScoped<IProductsService, eCommerce.BusinessLogicLayer.Services.ProductsService>();

    return services;
  }
}
